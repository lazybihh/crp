const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const homeRoutes = require("./routes/HomeRoutes");
const connectDB = require("./config/db");
const path = require("path");
const uploadsRoutes = require("./routes/uploadsRoutes");
dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());
// Make uploaded images accessible
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Image upload route
app.use("/api/uploads", uploadsRoutes);

// Connect MongoDB only when credentials are added
if (process.env.MONGO_URI) {
    connectDB();
}

app.use("/home", homeRoutes);

app.get("/", (req, res) => {
    res.send("Chhotu Ram Polytechnic API is running!");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});