
const express = require("express");
const router = express.Router();

const HomeContent = require("../models/HomeContent");

// GET Home Page content
router.get("/", async (req, res) => {
  try {
    const home = await HomeContent.findOne();

    if (!home) {
      return res.status(404).json({
        message: "Home Page content not found",
      });
    }

    res.status(200).json(home);
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch Home Page content",
      error: error.message,
    });
  }
});

// UPDATE Home Page content
router.put("/", async (req, res) => {
  try {
    const home = await HomeContent.findOneAndUpdate(
      {},
      { $set: req.body },
      {
        new: true,
        upsert: true,
        runValidators: true,
      }
    );

    res.status(200).json({
      message: "Home Page updated successfully",
      home,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to update Home Page",
      error: error.message,
    });
  }
});

module.exports = router;
