
const mongoose = require("mongoose");

const HomeContentSchema = new mongoose.Schema(
  {
    // Hero banners (images editable, banner tags remain static)
    banners: [
      {
        image: String,
        alt: String,
      },
    ],

    // Section headings and descriptions
    sectionContent: {
      whyChooseUs: {
        eyebrow: String,
        title: String,
        description: String,
      },

      leadership: {
        eyebrow: String,
        title: String,
      },

      notices: {
        eyebrow: String,
        title: String,
      },

      highlights: {
        eyebrow: String,
        title: String,
      },

      facilities: {
        eyebrow: String,
        title: String,
        description: String,
      },

      courses: {
        eyebrow: String,
        title: String,
        description: String,
      },

      recruiters: {
        eyebrow: String,
        title: String,
      },
    },

    // Latest news ticker
    latestNews: [
      {
        text: String,
        lang: String,
        to: String,
      },
    ],

    // College statistics
    stats: [
      {
        value: String,
        label: String,
      },
    ],

    // Why Choose Us
    reasons: [
      {
        title: String,
        text: String,
      },
    ],

    // Principal's message
    principal: {
      eyebrow: String,
      quote: String,
      paragraphs: [String],
      name: String,
      role: String,
      photo: String,
      link: {
        label: String,
        to: String,
      },
    },

    // Featured news card
    news: {
      tag: String,
      title: String,
      text: String,
      image: String,
    },

    // Leadership / Dignitaries
    dignitaries: [
      {
        name: String,
        role: String,
        text: String,
        image: String,
        initials: String,
      },
    ],

    // Selected notices from main Notices page
    noticeIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Notice",
      },
    ],

    // Selected facilities from main Facilities page
    facilityIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Facility",
      },
    ],

    // Selected events from main Events page
    eventIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Event",
      },
    ],

    // Selected achievements from main Achievements page
    achievementIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Achievement",
      },
    ],

    // Courses
    courses: [
      {
        id: String,
        name: String,
        seats: Number,
        tag: String,
        text: String,
      },
    ],

    // Recruiters (images editable)
    recruiters: [
      {
        name: String,
        logo: String,
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("HomeContent", HomeContentSchema);
