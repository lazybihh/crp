
import API_URL from "./api";

const SERVER_URL = API_URL.replace(/\/api\/?$/, "");

// Fetch Home Page content
export const getHomeContent = async () => {
  const response = await fetch(`${API_URL}/home`);

  if (!response.ok) {
    throw new Error("Failed to load Home Page content");
  }

  return response.json();
};

// Save Home Page content
export const saveHomeContent = async (data) => {
  const response = await fetch(`${API_URL}/home`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error("Failed to save Home Page content");
  }

  return response.json();
};

// Upload an image
export const uploadHomeImage = async (file) => {
  const formData = new FormData();
  formData.append("image", file);

  const response = await fetch(`${API_URL}/upload`, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error("Image upload failed");
  }

  const data = await response.json();

  return `${SERVER_URL}${data.imageUrl}`;
};
