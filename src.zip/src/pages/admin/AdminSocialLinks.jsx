import { Navigate } from "react-router-dom";
import "./AdminSocialLinks.css";

export default function AdminSocialLinks() { return <Navigate to="/admin/site-settings" replace />; }
