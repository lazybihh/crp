import { useEffect, useState } from "react";
import AdminSidebar from "./AdminSidebar";
import "./AdminFacultyEServices.css";
import { getService, saveService } from "../../services/facultyContentService";

export default function AdminFacultyEServices() {
  const [content, setContent] = useState(null);
  const [status, setStatus] = useState("");
  useEffect(() => { getService("e-services").then(row => setContent(row.content || row)).catch(error => setStatus(error.message)); }, []);
  const update = (field, value) => setContent(current => ({ ...current, [field]: value }));
  const submit = async (event) => { event.preventDefault(); setStatus("Saving…"); try { await saveService("e-services", content); setStatus("Saved successfully."); } catch (error) { setStatus(error.message); } };
  return <AdminSidebar title="Faculty e-services">
    <section className="faculty-content-editor" aria-labelledby="faculty-editor-heading">
      <h2 id="faculty-editor-heading">Edit Faculty e-services</h2>
      {!content ? <p>Loading page content…</p> : <form onSubmit={submit}>
        {[ ["title", "Title"], ["accent", "Title accent"], ["description", "Introduction"], ["featureKicker", "Feature label"], ["featureTitle", "Feature heading"], ["featureText", "Feature text"], ["sectionEyebrow", "Section label"], ["sectionTitle", "Section heading"], ["sectionText", "Section description"], ["noteTitle", "Note heading"], ["noteText", "Note text"], ["heroImage", "Banner image path"] ].map(([field,label]) => <label key={field} style={{display:"block",margin:"12px 0"}}>{label}<textarea rows={field.toLowerCase().includes("text") || field === "description" ? 3 : 1} value={content[field] || ""} onChange={event => update(field,event.target.value)} style={{display:"block",width:"100%",maxWidth:850,padding:10}} /></label>)}
        <p>Cards and steps retain their existing fixed structure. Edit the text in the corresponding page fields; items cannot be added or removed here.</p>
        <button type="submit">Save changes</button> <a href="/faculty/e-services" target="_blank" rel="noreferrer">Preview page</a>
      </form>}
      <p role="status">{status}</p>
    </section>
  </AdminSidebar>;
}
